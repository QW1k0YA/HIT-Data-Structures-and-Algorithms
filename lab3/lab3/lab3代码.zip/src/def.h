//
// Created by User on 2024-04-22.
//

#ifndef LAB3_DEF_H
#define LAB3_DEF_H

#include "iostream"
#include "cstring"
#include "fstream"
#define FILEAD "F:\\datastruct\\lab\\lab3\\lab3\\src\\test.txt"
#define SIZE 10000
#define EPS 0.0000001
#define MYINFI 1000000

typedef struct e{
    int begin;
    int end;
    int cost;
//    int color;
}edge;









#endif //LAB3_DEF_H
