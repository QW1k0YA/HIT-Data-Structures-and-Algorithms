//
// Created by User on 2024-03-18.
//
#include <iostream>
using namespace std;
#include "def.h"

position End(LIST L)
{
    return(L.last + 1);
}