//
// Created by User on 2024-03-25.
//

#ifndef LAB1_STACK_H
#define LAB1_STACK_H

#include "iostream"
using namespace std;
#define MAX 100
typedef char ElemType;

typedef struct{
    ElemType elements[MAX];
    int top ;

}STACK;
typedef struct{
    int elements[MAX];
    int top ;

}STACK_;
char popstack(STACK &S);
void pushstack(STACK &S,char n);
void pushstack_(STACK_ &S,int n);
int popstack_(STACK_ &S);
void loadfile(string filename,char (&Txt)[MAX] );
void printstack(const STACK& s);
void printstack_(const STACK_& s);
#endif //LAB1_STACK_H
/*
 #include "Stack.h"
#include "math.h"

int main()
{
    char str[MAX];
    scanf("%s",str);

    char strre[MAX];
    //װ���
    STACK op;
    op.top = -1;


    int i = 0,j = 0;
    int numb[MAX] = {0};
    int m = 0;
    while(str[i]!='\0')
    {
        if((str[i] != '+') && (str[i] != '-') &&  (str[i] != '*') && (str[i] != '/') && (str[i] != '(') &&  (str[i] != ')'))
        {
            strre[j++] = str[i];
            numb[m]++;
        }
        //����׺����ʽ������������ɨ�裬���������˳�򱣳�
        //���䣬���ԣ�������������ʱֱ�����
        else
        {
            if(str[i]!='(' && str[i]!=')')
            {
                m++;
            }
            if(op.top == -1)
            {
                pushstack(op,str[i]);
            }
            else if(str[i] == '(')
            {
                pushstack(op,str[i]);
            }
            else if((str[i] == '*' || str[i] =='/') && (op.elements[op.top] == '+' || op.elements[op.top] == '-'))
            {
                pushstack(op, str[i]);

                //*+
            }
            else if(str[i] == ')')
            {
                while(op.elements[op.top] != '(')
                {
                    strre[j++] = popstack(op);
                }
                popstack(op);
            }
            else if(str[i] == '+' || str[i] =='-')
            {
                while(op.elements[op.top] != '(')
                {
                    strre[j++] = popstack(op);
                }
                pushstack(op,str[i]);

            }
            //++ +*
            else
            {
                while(op.elements[op.top] != '(' && op.elements[op.top] != '+' && op.elements[op.top] != '-')
                {
                    strre[j++] = popstack(op);
                }
                pushstack(op,str[i]);

            }
            //**
        }

        i++;
    }

    if(op.top != -1)
    {
        while(op.top != -1)
        {
            strre[j++] = popstack(op);
        }
    }
    //postfix expression

    STACK opnum;
    opnum.top = -1;
    int result = 0;
    int num = 0;
    m = 0;
    int flagg = 0;
    for(int k = 0;k < j;k++)
    {
        if(strre[k] != '+' && strre[k] != '-' && strre[k] != '*' && strre[k] != '/' )
        {
                //��һ��
                if(num ==0 )
                {
                    pushstack(opnum,(strre[k] - '0')*int(pow(10,numb[m]-num-1)));
                    num++;

                }
                else
                {
                    if(numb[m] - num != 0)
                    {
                        opnum.elements[opnum.top] += (strre[k] - '0')*int(pow(10,numb[m]-num-1));
                        num++;
                    }
                    else
                    {
                        m++;
                        num = 0;
                        pushstack(opnum,(strre[k] - '0')*int(pow(10,numb[m]-num-1)));
                        num++;
                    }
                }

            //num++ ֱ��numb[m] - num == 0 m++
            //
            //�Ժ�



        }
        else
        {


            char temp1 = popstack(opnum);
            char temp2 = popstack(opnum);
            char temp3;
            switch (strre[k])
            {
                case '+':
                {
                    temp3 =  temp1 +temp2 ;
                    break;
                }
                case '-':
                {
                    temp3 =  temp2 -temp1 ;
                    break;
                }
                case '*':
                {
                    temp3 = temp1 *temp2;
                    break;
                }
                case '/':
                {
                    temp3 = temp2 /temp1 ;
                    break;
                }
            }
            pushstack(opnum,temp3);
        }
    }


    for(int l = 0;l < j;l++)
    {
        cout << strre[l];
    }
    cout <<endl;
    printf("%d",int(opnum.elements[0]));
}

 */